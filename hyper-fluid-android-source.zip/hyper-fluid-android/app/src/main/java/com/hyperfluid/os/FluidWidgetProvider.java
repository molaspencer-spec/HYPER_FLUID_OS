package com.hyperfluid.os;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FluidWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm", Locale.getDefault());
        SimpleDateFormat dateFmt = new SimpleDateFormat("EEE · d MMM", Locale.getDefault());
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.fluid_widget_placeholder);
            Date now = new Date();
            views.setTextViewText(R.id.widget_time, timeFmt.format(now));
            views.setTextViewText(R.id.widget_date, dateFmt.format(now) + " · HYPER FLUID");
            Intent open = new Intent(context, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.widget_time, pi);
            views.setOnClickPendingIntent(R.id.widget_date, pi);
            manager.updateAppWidget(id, views);
        }
    }
    public static void refresh(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, FluidWidgetProvider.class));
        new FluidWidgetProvider().onUpdate(context, manager, ids);
    }
}
