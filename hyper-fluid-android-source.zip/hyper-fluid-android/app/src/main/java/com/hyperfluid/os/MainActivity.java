package com.hyperfluid.os;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.media.AudioManager;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(10,12,16), SURFACE = Color.rgb(25,27,34), HIGH = Color.rgb(40,46,59);
    private static final int TEXT = Color.rgb(245,247,250), MUTED = Color.rgb(148,158,174), BLUE = Color.rgb(0,119,255), TEAL = Color.rgb(0,197,176), ORANGE = Color.rgb(255,105,0);
    private SharedPreferences prefs;
    private LinearLayout root, content;
    private int accent;
    private String currentPage = "Home";

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("hyper_fluid", MODE_PRIVATE);
        accent = prefs.getInt("accent", BLUE);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarDividerColor(Color.TRANSPARENT);
        render("Home");
    }

    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setFontFeatureSettings("tnum"); t.setTypeface(Typeface.create(bold ? "sans-serif" : "sans-serif-light", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }

    private void render(String page) {
        currentPage = page;
        root = vertical(); root.setBackgroundColor(BG); pad(root, 16, 14, 16, 8);
        LinearLayout top = horizontal();
        TextView mark = text("✳", 27, BG, true); mark.setGravity(Gravity.CENTER); mark.setBackground(shape(TEAL,16,BLUE)); top.addView(mark, lp(44,44));
        LinearLayout brand = vertical(); pad(brand,12,0,0,0); brand.addView(text("HYPER FLUID",16,TEXT,true)); brand.addView(text("SYSTEM INTERFACE · 01",9,MUTED,true));
        top.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));
        Button palette = button("◐", SURFACE, TEXT); top.addView(palette,lp(44,42)); palette.setOnClickListener(v -> cycleAccent());
        root.addView(top,lp(-1,50));
        ScrollView scroller = new ScrollView(this); scroller.setFillViewport(false); scroller.setClipToPadding(false);
        content = vertical(); pad(content,0,10,0,16); scroller.addView(content);
        root.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = horizontal(); nav.setBackground(shape(Color.rgb(28,32,41),24,Color.rgb(57,64,78))); pad(nav,5,5,5,5);
        String[] pages={"Home","Controls","Personalise"}; String[] icons={"⌂","☷","✧"};
        for(int i=0;i<pages.length;i++){ final String p=pages[i]; Button b=button(icons[i]+"  "+p,p.equals(page)?0x333B91FF:Color.TRANSPARENT,p.equals(page)?Color.rgb(174,198,255):MUTED); b.setTextSize(11); nav.addView(b,new LinearLayout.LayoutParams(0,dp(44),1)); b.setOnClickListener(v->render(p)); }
        root.addView(nav,lp(-1,54)); setContentView(root);
        if(page.equals("Home")) buildHome(); else if(page.equals("Controls")) buildControls(); else buildPersonalise();
    }
    private Button button(String label, int color, int fg) {
        Button b=new Button(this); b.setText(label); b.setTextColor(fg); b.setTextSize(13); b.setAllCaps(false); b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        b.setPadding(dp(9),dp(5),dp(9),dp(5)); b.setMinHeight(0); b.setMinimumHeight(0); b.setBackground(shape(color,15,Color.rgb(58,64,77))); return b;
    }
    private void section(String label) { TextView t=text(label.toUpperCase(Locale.ROOT),10,MUTED,true); t.setLetterSpacing(.12f); LinearLayout.LayoutParams p=lp(-1,30); p.topMargin=dp(8); content.addView(t,p); }
    private LinearLayout card() { LinearLayout c=vertical(); c.setBackground(shape(SURFACE,25,Color.rgb(54,59,71))); pad(c,17,16,17,17); LinearLayout.LayoutParams p=lp(-1,-2); p.bottomMargin=dp(12); content.addView(c,p); return c; }
    private void buildHome() {
        section("Your space, in sync");
        LinearLayout hero=card(); hero.addView(text("Everything.",34,TEXT,true)); hero.addView(text("In flow.",34,accent,true)); hero.addView(text("A calmer control centre for your phone.",12,MUTED,false));
        TextView clock=text(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),54,TEXT,true); LinearLayout.LayoutParams cp=lp(-1,68); cp.topMargin=dp(16); hero.addView(clock,cp);
        hero.addView(text(new SimpleDateFormat("EEEE · d MMMM yyyy",Locale.getDefault()).format(new Date()),12,MUTED,false));
        LinearLayout status=horizontal(); status.setGravity(Gravity.CENTER_VERTICAL); status.addView(text("●  SYSTEM READY",10,TEAL,true)); status.addView(new View(this),new LinearLayout.LayoutParams(0,1,1)); status.addView(text("ANDROID "+Build.VERSION.RELEASE,9,MUTED,true)); LinearLayout.LayoutParams sp=lp(-1,30); sp.topMargin=dp(12); hero.addView(status,sp);
        section("At a glance");
        LinearLayout metrics=horizontal(); metrics.setGravity(Gravity.TOP); content.addView(metrics,lp(-1,-2));
        int battery=((BatteryManager)getSystemService(BATTERY_SERVICE)).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY); if(battery<0)battery=0;
        metrics.addView(metric("BATTERY",battery+"%","Device reading",TEAL),new LinearLayout.LayoutParams(0,dp(110),1));
        metrics.addView(metric("DISPLAY","OLED STYLE","Dark surfaces",accent),new LinearLayout.LayoutParams(0,dp(110),1));
        metrics.addView(metric("VERSION","1.0.0","Hyper Fluid",ORANGE),new LinearLayout.LayoutParams(0,dp(110),1));
        section("Launch pad");
        LinearLayout apps=card(); apps.addView(text("Your installed apps",14,TEXT,true)); apps.addView(text("Tap an app to launch it. Long-press an app icon on the launcher to manage shortcuts.",11,MUTED,false));
        Button all=button("OPEN APP DRAWER  ↗",accent,Color.WHITE); LinearLayout.LayoutParams ap=lp(-1,48); ap.topMargin=dp(12); apps.addView(all,ap); all.setOnClickListener(v->showApps());
        section("Quick actions");
        LinearLayout actions=horizontal(); content.addView(actions,lp(-1,52));
        Button ctl=button("☷  Controls",HIGH,TEXT), per=button("✧  Personalise",HIGH,TEXT); actions.addView(ctl,new LinearLayout.LayoutParams(0,dp(48),1)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(48),1); rp.leftMargin=dp(9); actions.addView(per,rp); ctl.setOnClickListener(v->render("Controls")); per.setOnClickListener(v->render("Personalise"));
        section("Make it yours"); LinearLayout launcher=card(); launcher.addView(text("Use Hyper Fluid as your launcher",14,TEXT,true)); launcher.addView(text("Set this app as your default Home app to use its launcher screen.",11,MUTED,false)); Button choose=button("SET DEFAULT LAUNCHER",accent,Color.WHITE); LinearLayout.LayoutParams ch=lp(-1,46); ch.topMargin=dp(12); launcher.addView(choose,ch); choose.setOnClickListener(v->openHomeSettings());
    }
    private LinearLayout metric(String label,String value,String hint,int color){LinearLayout c=vertical();c.setBackground(shape(Color.rgb(30,33,42),18,Color.rgb(50,56,68)));pad(c,11,12,7,8);c.addView(text(label,9,MUTED,true));TextView val=text(value,17,color,true);LinearLayout.LayoutParams p=lp(-1,32);p.topMargin=dp(5);c.addView(val,p);c.addView(text(hint,9,MUTED,false));return c;}

    private void buildControls() {
        section("Control centre"); LinearLayout intro=card(); intro.addView(text("Fluid controls",25,TEXT,true)); intro.addView(text("Changes that need protected Android access will open the relevant system settings.",11,MUTED,false));
        section("Connectivity & focus");
        addAction("◉  Wi-Fi settings","Manage Wi-Fi through Android system settings",()->openSettings(Settings.ACTION_WIFI_SETTINGS));
        addAction("ᛒ  Bluetooth settings","Pair devices and manage Bluetooth",()->openSettings(Settings.ACTION_BLUETOOTH_SETTINGS));
        addAction("☾  Do not disturb","Requires notification policy access",()->toggleDnd());
        addAction("ϟ  Battery settings","Open system battery controls",()->openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        section("Sound & display");
        LinearLayout sound=card(); AudioManager audio=(AudioManager)getSystemService(AUDIO_SERVICE); int max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC), cur=audio.getStreamVolume(AudioManager.STREAM_MUSIC);
        addSlider(sound,"MEDIA VOLUME",cur,max,progress->audio.setStreamVolume(AudioManager.STREAM_MUSIC,progress,0));
        TextView hint=text("Volume is connected to Android's media stream.",10,MUTED,false); LinearLayout.LayoutParams hp=lp(-1,-2);hp.topMargin=dp(5);sound.addView(hint,hp);
        int brightness=128;try{brightness=Settings.System.getInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS);}catch(Exception ignored){}
        final int br=brightness; addSlider(sound,"SCREEN BRIGHTNESS",br,255,progress->{if(!Settings.System.canWrite(this)){new AlertDialog.Builder(this).setTitle("Allow brightness control").setMessage("Android requires permission before Hyper Fluid can change system brightness.").setNegativeButton("Cancel",null).setPositiveButton("Open settings",(d,w)->{Intent i=new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:"+getPackageName()));startActivity(i);}).show();return;}try{Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,Math.max(10,progress));}catch(Exception e){toast("Couldn't change brightness");}});
        section("Appearance"); addAction("✧  Accent colour","Current: "+(accent==BLUE?"Hyper Blue":accent==TEAL?"Electric Teal":"Hyper Orange"),this::cycleAccent);
        addAction("▧  Wallpaper & display","Open Android wallpaper settings",()->openSettings("android.settings.WALLPAPER_SETTINGS"));
    }
    private interface ProgressAction { void onProgress(int p); }
    private void addSlider(LinearLayout parent,String title,int value,int max,ProgressAction action){TextView label=text(title+"  ·  "+Math.round(value*100.0/Math.max(1,max))+"%",10,MUTED,true);LinearLayout.LayoutParams lp=lp(-1,25);lp.topMargin=dp(8);parent.addView(label,lp);SeekBar bar=new SeekBar(this);bar.setMax(max);bar.setProgress(value);bar.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));bar.setThumbTintList(android.content.res.ColorStateList.valueOf(TEXT));parent.addView(bar,lp(-1,42));bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean user){label.setText(title+"  ·  "+Math.round(p*100.0/Math.max(1,max))+"%");if(user)action.onProgress(p);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});}
    private void addAction(String title,String subtitle,Runnable action){LinearLayout c=horizontal();c.setBackground(shape(SURFACE,18,Color.rgb(50,56,68)));pad(c,14,12,12,12);LinearLayout copy=vertical();copy.addView(text(title,13,TEXT,true));copy.addView(text(subtitle,10,MUTED,false));c.addView(copy,new LinearLayout.LayoutParams(0,-2,1));c.addView(text("›",26,accent,true));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(9);content.addView(c,p);c.setOnClickListener(v->action.run());}

    private void buildPersonalise() {
        section("Personalisation"); LinearLayout intro=card(); intro.addView(text("Make it yours.",27,TEXT,true)); intro.addView(text("A tactile, photon-infused interface with soft glass surfaces and luminous accents.",12,MUTED,false));
        section("Accent palette");
        addSwatch("Hyper Blue","#0077FF",BLUE); addSwatch("Electric Teal","#00C5B0",TEAL); addSwatch("Hyper Orange","#FF6900",ORANGE);
        section("Launcher setup"); addAction("⌂  Set default launcher","Choose Hyper Fluid from Android Home settings",this::openHomeSettings);
        addAction("▦  Add clock widget","Add the Hyper Fluid clock widget from your home screen's widget picker",()->new AlertDialog.Builder(this).setTitle("Add Hyper Fluid widget").setMessage("Long-press an empty area on your home screen, choose Widgets, then select Hyper Fluid OS. If you're using another launcher, its widget picker controls placement.").setPositiveButton("Got it",null).show());
        section("About"); LinearLayout about=card();about.addView(text("HYPER FLUID SYSTEM",13,TEXT,true));about.addView(text("Version 1.0.0 · Native Android · No AI · No accounts · No API keys",10,MUTED,false));about.addView(text("Some protected controls must be changed through Android settings. Wi-Fi toggling is restricted by modern Android; this app opens the system control instead.",10,MUTED,false));
    }
    private void addSwatch(String name,String hex,int color){LinearLayout row=horizontal();row.setBackground(shape(SURFACE,18,Color.rgb(50,56,68)));pad(row,14,12,14,12);View swatch=new View(this);swatch.setBackground(shape(color,10,Color.rgb(255,255,255)));row.addView(swatch,lp(34,34));LinearLayout col=vertical();pad(col,12,0,0,0);col.addView(text(name,13,TEXT,true));col.addView(text(hex,10,MUTED,false));row.addView(col,new LinearLayout.LayoutParams(0,-2,1));row.addView(text(accent==color?"✓":"›",20,color,true));LinearLayout.LayoutParams p=lp(-1,60);p.bottomMargin=dp(9);content.addView(row,p);row.setOnClickListener(v->{accent=color;prefs.edit().putInt("accent",color).apply();render("Personalise");toast(name+" selected");});}
    private void cycleAccent(){accent=accent==BLUE?TEAL:accent==TEAL?ORANGE:BLUE;prefs.edit().putInt("accent",accent).apply();render(currentPage);toast("Accent updated");}
    private void openSettings(String action){try{startActivity(new Intent(action));}catch(Exception e){toast("This setting isn't available on this device");}}
    private void toggleDnd(){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=23&&!nm.isNotificationPolicyAccessGranted()){new AlertDialog.Builder(this).setTitle("Allow Do Not Disturb access").setMessage("Android requires your permission to change Do Not Disturb.").setNegativeButton("Cancel",null).setPositiveButton("Open settings",(d,w)->openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)).show();return;}if(Build.VERSION.SDK_INT>=23){boolean active=nm.getCurrentInterruptionFilter()!=NotificationManager.INTERRUPTION_FILTER_NONE;nm.setInterruptionFilter(active?NotificationManager.INTERRUPTION_FILTER_NONE:NotificationManager.INTERRUPTION_FILTER_ALL);toast(active?"Do Not Disturb enabled":"Do Not Disturb disabled");}}
    private void openHomeSettings(){try{if(Build.VERSION.SDK_INT>=29){Intent i=new Intent(Settings.ACTION_HOME_SETTINGS);startActivity(i);}else openSettings(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS);}catch(Exception e){openSettings(Settings.ACTION_SETTINGS);}}
    private void showApps(){
        PackageManager pm=getPackageManager();Intent query=new Intent(Intent.ACTION_MAIN,null);query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> found=pm.queryIntentActivities(query,0);Collections.sort(found,(a,b)->String.CASE_INSENSITIVE_ORDER.compare(a.loadLabel(pm).toString(),b.loadLabel(pm).toString()));
        LinearLayout list=vertical();pad(list,16,8,16,8);ScrollView sc=new ScrollView(this);sc.addView(list);
        for(android.content.pm.ResolveInfo ri:found){String label=ri.loadLabel(pm).toString();String pkg=ri.activityInfo.packageName;LinearLayout row=horizontal();pad(row,10,9,10,9);TextView icon=text("▣",21,accent,true);row.addView(icon,lp(38,40));LinearLayout copy=vertical();copy.addView(text(label,13,TEXT,true));copy.addView(text(pkg,9,MUTED,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));list.addView(row,lp(-1,55));row.setOnClickListener(v->{Intent launch=pm.getLaunchIntentForPackage(pkg);if(launch!=null)try{startActivity(launch);}catch(Exception e){toast("Unable to open app");}});}
        new AlertDialog.Builder(this).setTitle("App drawer · "+found.size()+" apps").setView(sc).setNegativeButton("Close",null).show();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onResume(){super.onResume();if(prefs!=null&&root!=null)FluidWidgetProvider.refresh(this);}
}
