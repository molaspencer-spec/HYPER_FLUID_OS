# Hyper Fluid OS — Native Android project

A native Java Android app starter for Android 8+ (targeting Android 15 / API 35), designed around the original Hyper Fluid dark-glass palette. Intended for a TECNO Spark running Android 14.

## Included
- Native home/launcher Activity (can be selected as the default Home app)
- App drawer that lists and launches installed apps
- Hyper Fluid dashboard with clock/date and live Android battery percentage
- Control panel with media volume adjustment, permission-gated brightness adjustment, DND access flow, and shortcuts to Wi-Fi/Bluetooth/battery settings
- Persistent accent colour preferences (Hyper Blue, Electric Teal, Hyper Orange)
- Home-screen clock widget
- GitHub Actions workflow that builds a debug APK and attaches it as a downloadable workflow artifact

## Build the APK in GitHub Actions
This workspace does not contain the Android SDK or Gradle, and network access is unavailable here, so an APK cannot be compiled directly in this environment. The project is ready for a remote Android build:

1. Extract this ZIP.
2. Upload the contents to a new GitHub repository (the `.github/workflows/build-apk.yml` file must be included).
3. Open the repository's **Actions** tab and run **Build Hyper Fluid OS APK** (or push to `main`).
4. When the workflow succeeds, open its run and download the `hyper-fluid-os-debug-apk` artifact. Extract it to get `app-debug.apk`.
5. Transfer the APK to the TECNO and install it. Android may ask you to allow installs from the browser/file manager used to open it.
6. Open Hyper Fluid OS and, if desired, use **Set default launcher** to choose it as your Home app.

## Important Android limitations
- Android 10+ restricts apps from directly enabling/disabling Wi-Fi. The Wi-Fi button opens Android settings instead.
- Brightness control requires the user to grant Modify System Settings access.
- Do Not Disturb changes require Notification Policy Access.
- Volume changes affect the media stream; no microphone recording, AI, network API, or account is used.
- The launcher is a native app, but it does not replace the lock screen, system status bar, OEM quick settings, or system Settings app. Those require deeper OS integration and cannot be replaced by an ordinary third-party app.

## Project
- `app/src/main/java/com/hyperfluid/os/MainActivity.java` — app screens and interactions
- `app/src/main/java/com/hyperfluid/os/FluidWidgetProvider.java` — clock widget
- `app/src/main/AndroidManifest.xml` — launcher and widget declarations
